function sumar(){
    let numero1 = document.getElementById('numeroUno').value 
    let numero2 = document.getElementById('numeroDos').value 
    alert(parseInt(numero1)+ parseInt(numero2));
}