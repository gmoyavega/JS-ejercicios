function Mostrar(){
    let cantidad = prompt('ingrese un numero: ')
    for(let i = 0; i < cantidad; i++)
    {alert('Hola UTN FRA')}
}