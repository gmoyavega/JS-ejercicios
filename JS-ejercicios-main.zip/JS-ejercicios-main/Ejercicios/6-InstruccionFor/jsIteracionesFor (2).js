function Mostrar(){
    for(let cont = 10; cont > 0; cont--)
        alert(cont)
}