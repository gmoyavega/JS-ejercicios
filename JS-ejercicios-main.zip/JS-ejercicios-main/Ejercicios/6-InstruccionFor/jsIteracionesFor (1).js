function Mostrar(){
    for(let vuelta = 1; vuelta < 11; vuelta++)
        alert(vuelta)
}