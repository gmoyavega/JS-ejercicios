function Mostrar(){
    for(;;){
        let variab = prompt('ingrese algo, o BREAK para terminar: ')
        if (variab == 'BREAK'){
            break
        }
    }
}