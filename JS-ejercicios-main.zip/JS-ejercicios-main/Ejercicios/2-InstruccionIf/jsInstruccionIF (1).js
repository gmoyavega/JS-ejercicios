function Mostrar(){
    let edad = document.getElementById('edad').value
    if (edad == 15)
    {alert('niña bonita')}
}