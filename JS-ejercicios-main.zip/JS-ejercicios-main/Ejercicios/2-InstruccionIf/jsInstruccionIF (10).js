function Mostrar(){
    let nota = Math.random()*10

    if (nota >= 9){
        alert('nota:' + nota + ' excelente')
    }
    else if (nota >= 4){
        alert('nota:' + nota + ' aprobo')
    }
    else{
        alert('nota:' + nota + ' vamos, la proxima se puede')
    }
}