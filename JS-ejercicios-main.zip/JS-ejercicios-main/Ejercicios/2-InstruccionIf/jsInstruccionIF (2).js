function Mostrar(){
    let edad = document.getElementById('edad').value 
    if (edad >= 18)
    {alert('mayor de edad')}
}