function Mostrar(){
    let numero = prompt('ingrese un numero: ')
    let contador = 1
    let suma = parseInt(numero)

    while (contador < 5){
        numero = prompt('ingrese un numero: ')
        contador ++
        suma += parseInt(numero)
    }

let promedio = suma / 5

    document.getElementById('suma').value=suma
    document.getElementById('promedio').value=promedio
}