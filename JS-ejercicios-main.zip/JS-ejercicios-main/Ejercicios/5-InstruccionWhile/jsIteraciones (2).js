function Mostrar(){
    let numero = 10

    while (numero > 0){
        alert(numero)
        numero--
    }
}