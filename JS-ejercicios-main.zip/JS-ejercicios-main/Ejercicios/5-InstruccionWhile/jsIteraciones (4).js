function Mostrar(){

    let numero = prompt('ingrese un numero entre 0 y 9 inclusive: ')

    while (numero < 0 && numero > 9){
        alert('numero invalido, intentelo de nuevo')
        numero = prompt('ingrese un numero entre 0 y 9 inclusive: ')
    }

    document.getElementById('Numero').value=numero
}
