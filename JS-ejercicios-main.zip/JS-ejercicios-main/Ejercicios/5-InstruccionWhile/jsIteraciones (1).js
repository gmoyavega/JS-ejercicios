function Mostrar(){
    let numero = 1

    while (numero < 11){
        alert(numero)
        numero++
    }
}