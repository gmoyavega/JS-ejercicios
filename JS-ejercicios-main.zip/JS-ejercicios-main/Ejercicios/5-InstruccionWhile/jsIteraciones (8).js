function Mostrar(){

    let positivos = 0
    let negativos = 1

    do {
        let numero = prompt('ingrese un numero: ')
        var confirmacion = confirm('dese agregar otro numero?')

        if (numero > 0){
            positivos += parseInt(numero)
        }
        else{
            negativos *= parseInt(numero)
        }

    } while (confirmacion == true)

    if (confirmacion == false){
        document.getElementById('suma').value=positivos
        document.getElementById('producto').value=negativos
    }
    
}