function Mostrar(){
    let mes = document.getElementById('mes').value 

    switch(mes){
        case 'Enero':
        case 'Marzo':
        case 'Mayo':
        case 'Julio':
        case 'Agosto':
        case 'Octurbe':
        case 'Diciembre':
            alert('este mes tiene 31 dias')
            break;
        case 'Febrero':
            alert('este mes tiene 29 dias')
            break;
        default:
            alert('este mes tiene 30 dias')
            break;
    }
}