function sumar() {
    let precio1 = document.getElementById('precio1').value 
    let precio2 = document.getElementById('precio2').value 
    let precio3 = document.getElementById('precio3').value 

    alert(parseInt(precio1) + parseInt(precio2) + parseInt(precio3))
}

function promedio() {
    let precio1 = document.getElementById('precio1').value 
    let precio2 = document.getElementById('precio2').value 
    let precio3 = document.getElementById('precio3').value 
   
    alert((parseInt(precio1) + parseInt(precio2) + parseInt(precio3))/3)
}

function iva() {
    let precio1 = document.getElementById('precio1').value 
    let precio2 = document.getElementById('precio2').value 
    let precio3 = document.getElementById('precio3').value 

    let suma = parseInt(precio1) + parseInt(precio2) + parseInt(precio3)
    alert((suma * 0.21) + suma)
}