function CalcularPrecio() {
    let cantidad = document.getElementById('Cantidad').value 
    let marca = document.getElementById('Marca').value 
    
    if (cantidad >= 6 ) {
        let resultado = 35*parseInt(cantidad)
        var precio_descuento = resultado / 2 
    }
    else if (cantidad = 5) {
        if (marca = 'ArgentinaLuz') {
            let resultado = 35*parseInt(cantidad)
            let deascuento =
            var precio_descuento = 
        }
    }

    document.getElementById('PrecioDescuento').value=precio_descuento
}