function Rectangulo() {
    let largo = document.getElementById('largo').value 
    let ancho = document.getElementById('ancho').value 

    let total = (parseInt(largo) * parseInt(ancho))
    let alambre = total * 3 

    alert('cantidad de alambre a comprar: ' + alambre)
}

function Circulo() {
    let radio = document.getElementById('radio').value 

    let alambre =  2 * Math.PI * radio * 3

    alert('cantidad de alambre a comprar: ' + alambre)
}

function Materiales() {
    let largo = document.getElementById('largo').value 
    let ancho = document.getElementById('ancho').value 

    let total = (parseInt(largo) * parseInt(ancho))
    let cemento = total * 2
    let cal = total * 3

    alert('se necesitan ' + cemento + ' bolsas de cemento y ' + cal + ' bolsas de cal')
}