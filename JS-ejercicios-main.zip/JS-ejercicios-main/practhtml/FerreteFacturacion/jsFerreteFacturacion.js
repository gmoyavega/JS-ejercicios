function Sumar() {
    let precio1 = document.getElementById('PrecioUno').value
    let precio2 = document.getElementById('PrecioDos').value 
    let precio3 = document.getElementById('PrecioTres').value 
    alert (parseInt (precio1) + parseInt(precio2) + parseInt(precio3))
}

function Promedio() {
    precio1 = document.getElementById('PrecioUno').value
    precio2 = document.getElementById('PrecioDos').value 
    precio3 = document.getElementById('PrecioTres').value 
    alert ((parseInt(precio1) + parseInt(precio2) + parseInt(precio3))/3)
}

function PrecioFinal () {
    precio1 = document.getElementById('PrecioUno').value
    precio2 = document.getElementById('PrecioDos').value 
    precio3 = document.getElementById('PrecioTres').value 
    let total = parseInt (precio1) + parseInt(precio2) + parseInt(precio3)
    alert ((total * 0.21) + total)
}