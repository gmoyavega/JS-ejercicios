function Mostrar(){
    let edad = document.getElementById('edad').value 
    let estado_civil = document.getElementById('estadoCivil').value 

    if (edad < 18 && estado_civil != "Soltero")
        alert('es muy pequeño para nos er soltero')
}