function Mostrar(){
    alert(Math.random()*10)
}