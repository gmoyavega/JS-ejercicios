function Mostrar(){
    let edad = document.getElementById('edad').value 
    if (edad >= 18 )
    {alert('usted no es adolescente')}
}