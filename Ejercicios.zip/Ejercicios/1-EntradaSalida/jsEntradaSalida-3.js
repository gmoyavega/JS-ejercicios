function Mostar(){
    let dato = document.getElementById('elNombre').value ;
    alert (dato)
}