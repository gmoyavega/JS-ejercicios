function Mostar(){
    let nombre = document.getElementById('elNombre').value 
    let edad = document.getElementById('laEdad').value
    alert('usted se llama ' + nombre + ' y tiene ' + edad + ' años')
}