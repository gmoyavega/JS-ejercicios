function SacarResto(){
    let dividendo = document.getElementById('numeroDividendo').value 
    let divisor = document.getElementById('numeroDivisor').value 
    alert(parseInt(dividendo) % parseInt(divisor))
}