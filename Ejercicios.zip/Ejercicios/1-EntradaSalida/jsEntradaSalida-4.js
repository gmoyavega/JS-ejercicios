function Mostar(){
    let dato = prompt('ingrese su nombre: ')
    document.getElementById('elNombre').value=dato
}