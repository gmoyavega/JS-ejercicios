function Mostar(){
    let nombre = prompt('ingrese su nombre: ')
    alert('hola ' + nombre)
}