function Mostrar(){

    let positivos = 0
    let cant_positivos = 0
    let negativos = 0
    let cant_negativos = 0
    let cant_ceros = 0
    let numeros_pares = 0

    do{
        let numero = prompt('ingresa un numero: ')
        var confirmacion = confirm('¿quieres agregar otro numero?')

        if (numero == 0){
            cant_ceros += 1
        }
        else if (numero > 0){
            positivos += parseInt(numero)
            cant_positivos += 1
        }
        else{
            negativos += parseInt(numero)
            cant_negativos += 1
        }

        if (parseInt(numero) % 2 == 0){
            numeros_pares += 1
        }



    } while (confirmacion == true)

    document.write('suma de los negativos: ' +  negativos)
    document.write('suma de los positivos: ' + positivos)
    document.write('cantidad de positivos: ' + cant_positivos)
    document.write('cantidad de negativos' + cant_negativos)
    document.write('cantidad de ceros: ' + cant_ceros)
    document.write('cantidad de numeros pares' + numeros_pares)
    document.write('promedio de positivos: ' + (positivos/cant_positivos))
    document.write('promedio de negativos: ' + (negativos/cant_negativos))
    document.write('diferencia entre positivos y negativos: ' + (positivos-negativos))
}