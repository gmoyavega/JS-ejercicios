function Mostrar(){
    var sexo = prompt('ingrese su sexo (f/m): ');

    while (sexo != "f" && sexo != "m"){
        sexo = prompt('el dato ingresado no es valido. (f/m): ')
    }

    if (sexo == 'f')
    {document.getElementById('Sexo').value='femenino'}
    else if (sexo == 'm')
    {document.getElementById('Sexo').value='masculino'}
}