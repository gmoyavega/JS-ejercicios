function Mostrar(){
    let numero = prompt('ingrese un numero: ')
    let confirmacion = confirm('¿desea agregar otro numero?')
    contador = 1 
    suma = parseInt(numero)

    while (confirmacion == true){
        numero = prompt('ingrese un numero: ')
        confirmacion = confirm('desea agregar numero: ')
        contador ++
        suma += parseInt(numero)
    }

    if (confirmacion == false)
    {document.getElementById('suma').value=suma}
    let promedio = suma / parseInt(contador)
    document.getElementById('promedio').value=promedio
}