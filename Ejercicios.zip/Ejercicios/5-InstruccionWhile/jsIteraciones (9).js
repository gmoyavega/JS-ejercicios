function Mostrar(){

   
    let numero1 = prompt('ingrese un numero: ')
    let minimo = numero1
    let maximo = numero1
    let confirmacion = confirm('¿quiere agregar otro numero?')

while (confirmacion == true){
    let numero2 = prompt('ingrese otro numero: ')
    
    if (numero2 > maximo){
        maximo = numero2
    }
    if (numero2 < minimo){
        minimo = numero2
    }

    confirmacion =  confirm('¿quiere agregar otro numero?')

}

if (confirmacion == false){
    document.getElementById('minimo').value=minimo
    document.getElementById('maximo').value=maximo
}
    
}