function Mostrar(){
    let clave = prompt('ingrese la clave: ')

    while (clave != 'utn750'){
        clave = prompt('incorrecto, intentelo de nuevo: ')
    }

}