function Mostrar(){
    let clave = prompt('ingrese la clave: ')
}