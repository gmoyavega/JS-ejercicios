function Mostrar(){
    let contador = 0
    let numero = prompt('ingrese un numero')
    for(let i = 1; i <= numero; i++){
        if (numero%i == 0){
            contador++
        }
    }
    
     if (contador == 2){
            alert('es primo')
    }
    else{
            alert('no es primo')
    }
}