function Mostrar(){
    for(let i= 0; ; i++){
        let numero= prompt('ingrese un numero: ')
        if (numero == 9){
            break
        }
    }
}