function Mostrar(){
    let numero =parseInt(prompt('ingrese un numero: ') )
    let pares = 0
    for (let i = 0; i < numero; i += 2)
    {
        alert(i)
        pares++
    }
        
    alert('se contaron ' + pares + ' numeros pares')
}