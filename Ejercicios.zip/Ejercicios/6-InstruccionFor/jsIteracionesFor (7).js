function Mostrar(){
    var numero = parseInt(prompt('ingrese un numero: '))
    var divisores = 0
    for (let i = 1; i <= numero; i++){
        if (numero%i == 0){
        alert(i)
        divisores++
        }
    }
}