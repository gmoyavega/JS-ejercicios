

function Fahrenheit() {
    let num = parseInt(document.getElementById('numero').value)
    let cent = ((num - 32 ) * 5) / 9

    alert(num + ' fahrenheit son ' + cent + ' centigrados')
}

function Centigrados() {
    let num = parseInt(document.getElementById('numero').value)
    let fahr = ((num * 9) / 5) + 32

    alert(num + ' centigrados son ' + fahr + ' fahrenheit')
}