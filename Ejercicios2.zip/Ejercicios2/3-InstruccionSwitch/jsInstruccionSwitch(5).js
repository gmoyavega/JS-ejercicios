function Mostrar(){
    let hora = document.getElementById("hora").value 
    switch (hora){
        case "7":
        case "8":
        case "9":
        case "10":
        case "11":
            alert("es de mañana")
            break;
        default:
            alert("no es de mañana")
    }
}