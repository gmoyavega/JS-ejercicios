function Mostrar(){
    let mes = document.getElementById("mes").value 
    switch (mes){
        case "Enero":
        case "Febrero":
        case "Marzo":
        case "Abril":
        case "Mayo":
            alert("falta para el invierno")
            break;
        case "Junio":
        case "Julio":
        case "Agosto":
            alert("abrigate que hace frio")
            break;
        case "Septiembre":
        case "Octubre":
        case "Noviembre":
        case "Diciembre":
            alert("ya pasamos el frio, ahora el calor!")
            break;
    }
}