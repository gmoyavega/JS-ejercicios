function Mostrar(){
    let edad = document.getElementById("edad").value 
    let estado = document.getElementById("estadoCivil").value 
    if (edad > 17 && estado == "Soltero"){
        alert("es soltero y no es menor de edad")
    }
}