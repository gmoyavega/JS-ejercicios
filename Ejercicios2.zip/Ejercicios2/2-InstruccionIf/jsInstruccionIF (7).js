function Mostrar(){
    let edad = document.getElementById("edad").value 
    let estado = document.getElementById("estadoCivil").value 
    if (edad < 18 && estado != "Soltero"){
        alert("es muy pequeño para no ser soltero")
    }
}