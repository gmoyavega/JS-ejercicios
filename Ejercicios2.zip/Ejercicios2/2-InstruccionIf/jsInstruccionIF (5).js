function Mostrar(){
    let edad = document.getElementById("edad").value 
    if (edad < 13 || edad > 17){
        alert("usted no es adolescente")
    }
}