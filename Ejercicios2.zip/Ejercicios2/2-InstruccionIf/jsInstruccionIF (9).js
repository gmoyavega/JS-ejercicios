function Mostrar(){
    alert(parseInt(Math.random()*10))
}