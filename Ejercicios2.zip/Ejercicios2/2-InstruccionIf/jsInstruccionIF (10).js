function Mostrar(){
    let nota = parseInt(Math.random()*10)+1
    if (nota > 3){
        if (nota > 8){
            alert("nota: " + nota + ". excelente")
        }
        else {
            alert("nota: " + nota + ". aprobo")
        }
    }
    else {
        alert("nota: " + nota + ". vamos, la proxima se puede")
    }
}