function Mostrar(){
    let edad = document.getElementById("edad").value 
    if (edad > 12 && edad < 18){
        alert("usted es adolescente")
    }
}