function Mostrar(){
    let edad = document.getElementById("edad").value 
    if (edad < 18){
        if (edad < 13){
            alert("eres un niño")
        }
        else{
            alert("eres un adolescente")
        }
    }
    else {
        alert("eres mayor de edad")
    }
}