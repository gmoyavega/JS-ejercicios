function Mostrar(){
    let contador = 0
    let suma = 0
    let confirmacion
    do {
        let numero = parseInt(prompt("ingrese un numero"))
        confirmacion = confirm("¿desea agregar otro numero?")
        contador ++
        suma += numero
    } while (confirmacion == true);
    document.getElementById("suma").value = suma
    document.getElementById("promedio").value = suma / contador
}