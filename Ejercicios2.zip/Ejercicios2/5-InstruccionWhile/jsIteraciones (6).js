function Mostrar(){
    let contador = 0
    let suma = 0
    do {
        let numero = parseInt(prompt("ingrese un numero:"))
        contador ++
        suma += numero
    } while (contador < 5);
    document.getElementById("suma").value = suma
    document.getElementById("promedio").value = suma / 5
}