function Mostrar(){
    let clave
    do { 
        clave = prompt("ingrese la clave:")
    } while (clave != "utn750")
}