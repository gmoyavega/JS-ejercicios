function Mostrar(){
    let contador  = 10
    while (contador >= 0){
        alert(contador)
        contador --
    }
}



