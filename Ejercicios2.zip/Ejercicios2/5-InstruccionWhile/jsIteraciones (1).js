function Mostrar(){
    let contador = 0
    while (contador <= 10){
        alert(contador)
        contador ++
    }
}