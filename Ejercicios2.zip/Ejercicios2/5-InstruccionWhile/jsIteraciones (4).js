function Mostrar(){
    let numero = prompt("ingrese un numero del 0 al 9:")
    do {
        numero = prompt("ingrese un numero del 0 al 9:")
    } while (numero < 0 || numero > 9 );
    document.getElementById("Numero").value = numero
}