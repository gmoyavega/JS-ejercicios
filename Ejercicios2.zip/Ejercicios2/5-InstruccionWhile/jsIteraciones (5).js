function Mostrar(){
    let sexo
    do {
        sexo = prompt("ingrese (f) para femenino o (m) para masculino")
    } while (sexo != "f" && sexo != "m");
    if (sexo == "f"){
        document.getElementById("Sexo").value = "femenino"
    }
    else{
        document.getElementById("Sexo").value = "masculino"
    }
}