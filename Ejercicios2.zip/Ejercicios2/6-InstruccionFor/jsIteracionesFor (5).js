function Mostrar(){
    for (;;){
        let numero = prompt("ingrese un numero: ")
        if (numero == 9){
            break
        }
    }
}