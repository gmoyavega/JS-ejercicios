function Mostrar(){
    for (;;){
        let v = prompt("ingrese algo o break para terminar: ")
        if (v == "break"){
            break
        }
    }
}