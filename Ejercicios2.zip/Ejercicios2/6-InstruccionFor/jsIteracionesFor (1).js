function Mostrar(){
    for (let i = 1; i <= 10; i++){
        alert(i)
    }
}