function Mostrar(){
    for (let i = 10; i >= 1; i--){
        alert(i)
    }
}


