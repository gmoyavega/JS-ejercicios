function Mostrar(){
    let cant = prompt("cuantas veces desea repetir el mensaje?")
    for (let i = 1; i <= cant; i++){
        alert("hola utn fra "+ i)
    }
}