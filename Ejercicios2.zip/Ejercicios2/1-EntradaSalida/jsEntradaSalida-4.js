function Mostar(){
    let edad = prompt("ingrese su nombre:")
    document.getElementById("elNombre").value = edad
}