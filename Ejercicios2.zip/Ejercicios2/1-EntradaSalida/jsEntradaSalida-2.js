function Mostar(){
    let nombre = prompt("¿cual es tu nombre?")
    alert("hola " + nombre)
}