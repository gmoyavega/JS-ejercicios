function MostrarAumento(){
    let sueldo = parseInt(document.getElementById("sueldo").value) 
    let aumento = sueldo + (sueldo * 0.1)
    document.getElementById("resultado").value = aumento
}