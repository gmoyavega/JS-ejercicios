function sumar() {
    let num1 = parseInt(document.getElementById("numeroUno").value);
    let num2 = parseInt(document.getElementById("numeroDos").value);

    let accion = "suma";
    let resultado = num1 + num2;

    alert("La " + accion + " es " + resultado);
}

function restar() {
    let num1 = parseInt(document.getElementById("numeroUno").value);
    let num2 = parseInt(document.getElementById("numeroDos").value);

    let accion = "resta";
    let resultado = num1 - num2;

    alert("La " + accion + " es " + resultado);
}

function multiplicar() {
    let num1 = parseInt(document.getElementById("numeroUno").value);
    let num2 = parseInt(document.getElementById("numeroDos").value);

    let accion = "multiplicación";
    let resultado = num1 * num2;

    alert("La " + accion + " es " + resultado);
}

function dividir() {
    let num1 = parseInt(document.getElementById("numeroUno").value);
    let num2 = parseInt(document.getElementById("numeroDos").value);

    let accion = "división";
    let resultado = num1 / num2;
}