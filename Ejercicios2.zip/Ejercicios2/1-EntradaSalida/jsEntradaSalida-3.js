function Mostar(){
    let nombre = document.getElementById("elNombre").value 
    alert("bienvenida " + nombre + ", como estas?")
}