function sumar(){
    let num1 = parseInt(document.getElementById("numeroUno").value)
    let num2 = parseInt(document.getElementById("numeroDos").value) 
    alert("la suma es " + (num1 + num2))
}