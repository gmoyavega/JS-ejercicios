function SacarResto(){
    let dividendo = parseInt(document.getElementById("numeroDividendo").value)
    let divisor =parseInt(document.getElementById("numeroDivisor").value) 
    alert("el resto es " + (dividendo % divisor))
}