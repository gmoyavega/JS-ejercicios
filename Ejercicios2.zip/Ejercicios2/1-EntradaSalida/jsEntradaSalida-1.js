function Mostar(){
    alert ("Esto funciona de maravilla")
}