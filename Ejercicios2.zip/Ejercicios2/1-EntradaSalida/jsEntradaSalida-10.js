function MostrarAumento(){
    let importe =parseInt(document.getElementById("importe").value) 
    let descuento = importe - (importe * 0.25)
    document.getElementById("resultado").value = descuento
}